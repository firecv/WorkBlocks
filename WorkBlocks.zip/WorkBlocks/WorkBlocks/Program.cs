﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using Spectre.Console;

namespace WorkBlocks
{
    public static class Global /* tutaj przechowywane "zmienne globalne" */
    {
        public static readonly string[] week = { "MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN" };
        public static readonly string[] defColors = { "black on white", "black on gray82", "black on magenta1", "white on purple4", "white on darkblue",
        "blue on cyan1", "black on yellow", "black on green1"};

        public const int pageLength = 12;
        public static double OvertimeRate { get; set; }
    }

    class Program
    {
        public static List<Block> blockList = new List<Block>();
        public static List<Shift> shiftList = new List<Shift>();
        public static List<Employee> employeeList = new List<Employee>();
        double overtimeRate = 2;
        int userMode = 0;

        static void Main(string[] args)
        {
            PresetOutput.StartUp();

            UserMode();
        }



        //MAIN USER MENUS
        static void UserMode()
        {
            int currentPage = 0, currentDay = 0;

            while (true)
            {
                PresetOutput.DisplayShiftBlocks(currentPage, currentDay);

                int choice = PresetInput.StaticChoiceMenu(0);

                switch (choice)
                {
                    case 0:
                        PresetInput.AnalysisMode(currentPage, currentDay);
                        break;
                    case 1:
                        currentDay++;
                        if (currentDay > 6)
                            currentDay = 0;
                        break;
                    case 2:
                        currentPage++;
                        if (currentPage > employeeList.Count / Global.pageLength)
                            currentPage = 0;
                        break;
                    case 3:
                        EmployeePayViewMode(currentPage, currentDay);
                        break;
                    case 4:
                        if (PresetInput.Login())
                            AdminMode();
                        else
                            PresetOutput.ErrorMessage(0);
                        break;
                    case 5:
                        DataHandling.SaveFile();
                        break;
                    case 6:
                        DataHandling.ReadFile();
                        break;
                    case 7:
                        PresetOutput.ShutDown();
                        return;
                    default:
                        break;
                }
            }
        }

        static void AdminMode(int page = 0, int day = 0)
        {
            int currentPage = page, currentDay = day;

            while (true)
            {
                PresetOutput.DisplayShiftBlocks(currentPage, currentDay);

                int choice = PresetInput.StaticChoiceMenu(1);

                switch (choice)
                {
                    case 0:
                        PresetInput.AnalysisMode(currentPage, currentDay);
                        break;
                    case 1:
                        currentDay++;
                        if (currentDay > 6)
                            currentDay = 0;
                        break;
                    case 2:
                        currentPage++;
                        if (currentPage > employeeList.Count / Global.pageLength)
                            currentPage = 0;
                        break;
                    case 3:
                        string newName = PresetInput.Request(2);

                        string newSur = PresetInput.Request(3);

                        string newPos = PresetInput.Request(4);

                        double conWage = PresetInput.RequestDouble(5);

                        DataHandling.CreateNewEmployee(newName, newSur, newPos, conWage);

                        PresetOutput.SuccessMessage(1);

                        break;
                    case 4:
                        EmployeeEditingMode(currentPage, currentDay);
                        break;
                    case 5:
                        ShiftManagementMode();
                        break;
                    case 6:
                        EmployeePayViewMode(currentPage, currentDay, true);
                        break;
                    case 7:
                        PresetInput.LoginDetailChangeAttempt();
                        break;
                    case 8:
                        DataHandling.SaveFile();
                        break;
                    case 9:
                        DataHandling.ReadFile();
                        break;
                    case 10:
                        PresetOutput.ShutDown();
                        return;
                    default:
                        break;
                }
            }
        }



        //BASIC MODES
        
        //metoda AnalysisMode zostal przeniesiony do PresetInput, poniewaz ona KOMPLETNIE zalezy od sposobu wyswietlenia danych
        
        static void EmployeePayViewMode(int page, int day, bool adminPerms = false)
        {
            int currentPage = 0, currentDay = 0;

            PresetOutput.DisplayEmployeePay(currentPage);

            while (true)
            {
                var choice = PresetInput.StaticChoiceMenu(2);

                switch (choice)
                {
                    case 0:
                        currentPage++;
                        if (currentPage > employeeList.Count / Global.pageLength)
                            currentPage = 0;
                        break;
                    case 1:
                        if (adminPerms)
                            Global.OvertimeRate = PresetInput.RequestDouble(6);
                        else
                            PresetOutput.ErrorMessage(2);
                        break;
                    case 2:
                        return;
                    default:
                        break;
                }

                PresetOutput.DisplayEmployeePay(currentPage);
            }
        }

        static void EmployeeEditingMode(int page, int day)
        {
            int currentPage = page, currentDay = day;

            int idEdit = PresetInput.RequestInt(8);

            if ((idEdit-1) <= employeeList.Count)
            {
                int eChoice;

                while (true)
                {
                    PresetOutput.DisplayShiftBlocks(currentPage, currentDay, idEdit-1);

                    eChoice = PresetInput.StaticChoiceMenu(4);

                    switch (eChoice)
                    {
                        case 0:
                            PresetInput.AnalysisMode(currentPage, currentDay);
                            break;
                        case 1:
                            currentDay++;
                            if (currentDay > 6)
                                currentDay = 0;
                            break;
                        case 2:
                            currentPage++;
                            if (currentPage > employeeList.Count / Global.pageLength)
                                currentPage = 0;
                            break;
                        case 3:
                            EmployeeShiftAssignmentMode(idEdit - 1);
                            break;
                        case 4:
                            employeeList[idEdit-1].Name = PresetInput.Request(9);
                            break;
                        case 5:
                            employeeList[idEdit - 1].Surname = PresetInput.Request(9);
                            break;
                        case 6:
                            employeeList[idEdit - 1].Position = PresetInput.Request(9);
                            break;
                        case 7:
                            employeeList[idEdit - 1].Wage = PresetInput.RequestDouble(9);
                            break;
                        case 8:
                            var conf = PresetInput.StaticChoiceMenu(5);

                            if (conf == 0)
                            {
                                for (int i = idEdit; i < employeeList.Count; i++)
                                {
                                    employeeList[i].Id--;
                                }
                                employeeList.RemoveAt(idEdit - 1);
                                PresetOutput.SuccessMessage(2);
                            }
                            return;
                        case 9:
                            return;
                    }
                }
            }
        }
        
        static void EmployeeShiftAssignmentMode(int idEdit)
        {
            List<string> allShifts = new List<string>();
            string[] createString = new string[26];

            PresetOutput.DisplayEmployeeFullView(idEdit);

            allShifts.Add("BACK");
            allShifts.Add("Create & Manage Shifts\n");

            foreach (Shift i in shiftList)
            {
                createString[25] = i.Title;
                createString[24] = "  ";

                Block a;
                for (int j = 0; j < 24; j++)
                {
                    int blockIndex = i.TimeCode[j];
                    if (blockIndex >= 0 && blockIndex < blockList.Count)
                    {
                        a = blockList[blockIndex];
                        createString[j] = "[" + a.Color + "]" + a.Typeset + "[/]";
                    }
                }

                allShifts.Add(string.Join("", createString));
            }

            while (true)
            {
                PresetOutput.DisplayEmployeeFullView(idEdit);

                int choice = PresetInput.DynamicChoiceMenu(0);
                if (choice == 0)
                    return;
                if (choice == 1)
                {
                    ShiftManagementMode();
                    continue;
                }

                int dayChoice = PresetInput.StaticChoiceMenu(6);

                employeeList[idEdit].SetShift(choice - 2, dayChoice);
            }
        }

        static void ShiftManagementMode()
        {
            while (true)
            {   
                int choice = PresetInput.DynamicChoiceMenu(1);

                if (choice == 0)
                    return;
                if (choice == 1)
                {
                    DataHandling.CreateNewShift("New Shift", "0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0");
                    ShiftEditingMode(shiftList.Count - 1);
                    continue;
                }
                if (choice == 2 || choice == 3)
                {
                    bool conf = PresetInput.RequestConfirmation();
                    if (conf)
                    {
                        ShiftEditingMode(choice - 2);
                        continue;
                    } 
                    else
                        continue;
                }

                ShiftEditingMode(choice - 2);
            }
        }

        static void ShiftEditingMode(int shiftEdit)
        {
            while (true)
            {
                PresetOutput.DisplaySingleShift(shiftEdit);

                int choice = PresetInput.DynamicChoiceMenu(2);

                if (choice == 0)
                    return;
                if (choice == 1)
                {
                    shiftList[shiftEdit].Title = PresetInput.Request(10);
                    continue;
                }
                if (choice == 2)
                {
                    BlockCreationMode();
                    continue;
                }
                
                PresetInput.ShiftBlockInsertion(shiftEdit, choice);
            }
        }

        static void BlockCreationMode()
        {
            string newTitle = "";
            string newTypeset = "";

            newTypeset = PresetInput.RequestTypeset();

            newTitle = PresetInput.Request(7);

            var choice = PresetInput.StaticChoiceMenu(3);

            if (choice == 8)
            {
                DataHandling.CreateNewBlock(newTitle, newTypeset, "black on red3_1", true);
            } else
            {
                DataHandling.CreateNewBlock(newTitle, newTypeset, Global.defColors[choice]);
            }

            return;
        }
    }
}
