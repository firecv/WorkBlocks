﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkBlocks
{
    public static class IdManager
    {
        private static int lastIdUsed = 0;
        private static int lastBlockIdUsed = 0;

        public static void PrimeClassesCoreValueReset()
        {
            lastIdUsed = 0;
            lastBlockIdUsed = 0;
        }

        public static int GetNextEmployeeId()
        {
            return ++lastIdUsed;
        }

        public static int GetNextBlockId()
        {
            return ++lastBlockIdUsed;
        }
    }

    public class Block
    {
        public int Id { get; private set; }
        public string Title { get; set; }
        public string Typeset { get; set; }
        public string Color { get; set; }

        public bool IsOvertime { get; set; }

        public Block(string title, string typeset, string color = "black on black", bool isOvertime = false)
        {
            Id = IdManager.GetNextBlockId();
            Title = title;
            Typeset = typeset;
            Color = color;
            IsOvertime = isOvertime;
        }

        public void setOvertime()
        {
            IsOvertime = true;
        }
    }

    public class Shift
    {
        public string Title { get; set; }
        public int[] TimeCode { get; set; } = new int[24];

        public Shift(string title, string timeCode)
        {
            Title = title;
            string[] tc = timeCode.Split('+');
            TimeCode = Array.ConvertAll(tc, int.Parse); ;
        }
    }

    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Position { get; set; }
        public double Wage { get; set; }
        public int[] Shifts { get; private set; } = new int[7]; // MON, TUE, WED, THU, FRI, SAT, SUN

        public Employee(string name, string surname, string position, double wage)
        {
            Id = IdManager.GetNextEmployeeId();
            Name = name;
            Surname = surname;
            Position = position;
            Wage = wage;
        }

        public void SetShift(int shiftId, int day)
        {
            if (day >= 0 && day < 7)
            {
                Shifts[day] = shiftId;
            }
        }
    }



    public class DataHandling
    {
        public static void CreateNewBlock(string title, string typeset, string note = "", bool ov = false)
        {
            if (!string.IsNullOrEmpty(title))
                Program.blockList.Add(new Block(title, typeset, note, ov));
        }

        public static void CreateNewShift(string title, string timeCode)
        {
            if (!string.IsNullOrEmpty(title) && !string.IsNullOrEmpty(timeCode))
                Program.shiftList.Add(new Shift(title, timeCode));
        }

        public static void CreateNewEmployee(string name, string surname, string position, double wage = 0)
        {
            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(surname) && !string.IsNullOrEmpty(position))
                Program.employeeList.Add(new Employee(name, surname, position, wage));
        }

        public static void InitializeStandardResources()
        {
            CreateNewBlock("Clocked Out", "..", "grey11 on grey11"); //0
            CreateNewBlock("Clocked In", "██", "white on white"); //1
            CreateNewBlock("Opening Business", "OP", "blue3 on aqua"); //2
            CreateNewBlock("Closing Business", "CL", "blue3 on aqua"); //3
            CreateNewBlock("Overtime", "██", "red3_1 on red3_1", true); //4
            CreateNewBlock("Meeting", "!!", "green on green3_1"); //5
            CreateNewBlock("Overtime Closing", "CL", "blue3 on red3_1", true); //6
            CreateNewBlock("15-min Break", "30", "black on gold1"); //7
            CreateNewBlock("30-min Break", "15", "olive on gold1"); //8

            CreateNewShift("Day Off", "0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0+0"); //0
            CreateNewShift("9 to 5", "0+0+0+0+0+0+0+0+0+1+1+1+1+1+1+1+1+0+0+0+0+0+0+0"); //1

            Global.OvertimeRate = 2.0;
        }


        public static void SaveFile()
        {
            File.WriteAllText("wbSavedEmployees.txt", string.Empty);
            File.WriteAllText("wbSavedShifts.txt", string.Empty);
            File.WriteAllText("wbSavedBlocks.txt", string.Empty);

            using (StreamWriter f = new StreamWriter("wbSavedEmployees.txt"))
            {
                foreach (var emp in Program.employeeList)
                {
                    string shifts = string.Join(" ", emp.Shifts);
                    f.WriteLine($"{emp.Id} {emp.Name} {emp.Surname} {emp.Wage} {shifts} {emp.Position}");
                }
            }

            using (StreamWriter f = new StreamWriter("wbSavedShifts.txt"))
            {
                string[] tof = new string[24];

                foreach (var shift in Program.shiftList)
                {
                    for (int i = 0; i < 24; i++)
                        tof[i] = shift.TimeCode[i].ToString();
                    f.WriteLine($"{string.Join("+", tof)} {shift.Title}");
                }
            }

            using (StreamWriter f = new StreamWriter("wbSavedBlocks.txt"))
            {
                foreach (var block in Program.blockList)
                {
                    f.WriteLine($"{block.Id} {block.Title} #%# {block.Typeset} {block.Color} {block.IsOvertime}");
                }
            }

            using (StreamWriter f = new StreamWriter("wbOvSetting.txt"))
            {
                f.WriteLine($"{Global.OvertimeRate}");
            }
        }

        public static void ResetAll()
        {
            Program.employeeList.Clear();
            Program.shiftList.Clear();
            Program.blockList.Clear();
            IdManager.PrimeClassesCoreValueReset();
        }

        public static void ReadFile()
        {
            ResetAll();
            int index = 0;

            foreach (var line in File.ReadAllLines("wbSavedEmployees.txt"))
            {
                var parts = line.Split();
                string noteTxt = string.Join(" ", parts, 11, parts.Length - 11).Trim();
                CreateNewEmployee(parts[1], parts[2], noteTxt, double.Parse(parts[3]));

                for (int shd = 0; shd < 7; shd++)
                    Program.employeeList[index].SetShift(int.Parse(parts[4 + shd]), shd);
                index++;
            }

            foreach (var line in File.ReadAllLines("wbSavedShifts.txt"))
            {
                var parts = line.Split();
                string noteTxt = string.Join(" ", parts, 1, parts.Length - 1).Trim();
                CreateNewShift(noteTxt, parts[0]);
            }

            foreach (var line in File.ReadAllLines("wbSavedBlocks.txt"))
            {
                var parts = line.Split();
                int num = Array.IndexOf(parts, "#%#");
                string titleTxt = string.Join(" ", parts, 1, num - 1).Trim();
                string noteTxt = string.Join(" ", parts, num + 2, parts.Length - num - 3).Trim();
                CreateNewBlock(titleTxt, parts[num + 1], noteTxt, bool.Parse(parts[parts.Length - 1]));
            }

            string ov = File.ReadAllText("wbOvSetting.txt");
            Global.OvertimeRate = double.Parse(ov);
        }


        public static string GetLoginDetails()
        {
            string line = File.ReadAllText("wbLogin.txt");
            return line;
        }

        public static void ChangeLoginDetails(string newLogin, string newPassword)
        {
            File.WriteAllText("wbLogin.txt", newLogin + " " + newPassword);
        }
    }
}
