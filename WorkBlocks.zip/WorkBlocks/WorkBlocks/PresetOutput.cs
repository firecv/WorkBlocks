﻿using Spectre.Console;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkBlocks
{
    internal class PresetOutput
    {
        public const String appTitle = "Work[black on red1]Bl[/][black on green3_1]oc[/][black on magenta3_2]ks[/]";
        public const String fancyUsernamePrompt = "Us[black on red1]er[/][black on green3_1]na[/][black on magenta3_2]me[/]: ";
        public const String fancyPasswordPrompt = "Pa[black on red1]ss[/][black on green3_1]wo[/][black on magenta3_2]rd[/]: ";

        public static void DisplaySingleShift(int shiftNo)
        {
            AnsiConsole.Clear();

            var shTable = new Table()
               .AddColumn("Title")
               .AddColumn("Schedule");

            shTable.Border = TableBorder.SimpleHeavy;

            string shMoniker = Program.shiftList[shiftNo].Title;

            if (shMoniker.Length > 28)
            {
                shMoniker = shMoniker.Substring(0, 25) + "...";
            }

            shTable.AddRow("                            ", "  01  03  05  07  09  11  13  15  17  19  21  23    ");
            shTable.AddRow(shMoniker, "00  02  04  06  08  10  12  14  16  18  20  22  TMRW");

            var shiftNum = Program.shiftList[shiftNo].TimeCode;
            string[] createString = new string[24];

            Block a;
            for (int j = 0; j < 24; j++)
            {
                int blockIndex = shiftNum[j];
                if (blockIndex >= 0 && blockIndex < Program.blockList.Count)
                {
                    a = Program.blockList[blockIndex];
                    createString[j] = "[" + a.Color + "]" + a.Typeset + "[/]";
                }
            }

            string finalString = string.Join("", createString);
            shTable.AddRow("                            ", finalString);

            var shPanel = new Panel(shTable);
            shPanel.Header = new PanelHeader(appTitle);
            shPanel.Border = BoxBorder.Heavy;
            shPanel.Padding = new Padding(0, 0, 1, 0);
            shPanel.Expand = true;
            AnsiConsole.Write(shPanel);
        }

        public static void DisplayEmployeeFullView(int idEdit)
        {
            AnsiConsole.Clear();

            var empTable = new Table()
               .AddColumn("ID")
               .AddColumn("Name & Surname")
               .AddColumn("Day")
               .AddColumn("Schedule");

            string empMoniker = Program.employeeList[idEdit].Name + " " + Program.employeeList[idEdit].Surname;

            if (empMoniker.Length > 28)
            {
                empMoniker = Program.employeeList[idEdit].Name.Substring(0, 1) + ". " + Program.employeeList[idEdit].Surname;
                if (empMoniker.Length > 28)
                {
                    empMoniker = empMoniker.Substring(0, 25) + "...";
                }
            }

            empTable.Border = TableBorder.SimpleHeavy;

            empTable.AddRow("  ", "                            ", "  ", "  01  03  05  07  09  11  13  15  17  19  21  23    ");
            empTable.AddRow(Program.employeeList[idEdit].Id.ToString(), empMoniker, "  ", "00  02  04  06  08  10  12  14  16  18  20  22  TMRW");

            string[] createString = new string[34];

            string finalString = "";

            for (int i = 0; i < 7; i++)
            {
                var shiftNum = Program.shiftList[Program.employeeList[idEdit].Shifts[i]].TimeCode;

                Block a;
                for (int j = 0; j < 24; j++)
                {
                    int blockIndex = shiftNum[j];
                    if (blockIndex >= 0 && blockIndex < Program.blockList.Count)
                    {
                        a = Program.blockList[blockIndex];
                        createString[j] = "[" + a.Color + "]" + a.Typeset + "[/]";
                    }
                }

                finalString = string.Join("", createString);
                empTable.AddRow("  ", "                            ", Global.week[i], finalString);

            }

            var empPanel = new Panel(empTable);
            empPanel.Header = new PanelHeader(appTitle);
            empPanel.Border = BoxBorder.Heavy;
            empPanel.Padding = new Padding(0, 0, 0, 0);
            empPanel.Expand = true;
            AnsiConsole.Write(empPanel);
        }

        public static void GenerateDetailText(int page, int day, int cursorX, int cursorY)
        {
            AnsiConsole.MarkupLine("Move the cursor with [yellow]the arrow keys[/]. To quit, press [yellow]esc[/].");

            int employeeIndex = 12 * page + cursorY - 5;
            int shiftIndex = Program.employeeList[employeeIndex].Shifts[day];
            int blockIndex = Program.shiftList[shiftIndex].TimeCode[(cursorX - 66) / 2];

            Block blockSelected = Program.blockList[blockIndex];
            AnsiConsole.MarkupLine("\n[steelblue1_1 on black]Shift ID: " + shiftIndex + "\n\nBlock ID: " + blockIndex + "[/]\n[" + blockSelected.Color + "]" + blockSelected.Typeset + "[/] [yellow]" + blockSelected.Title + "[/]");
        }

        public static void DisplayShiftBlocks(int page, int day, int highlight = -1)
        {
            AnsiConsole.Clear();

            var empTable = new Table()
                .AddColumn("ID")
                .AddColumn("Name & Surname")
                .AddColumn("Position")
                .AddColumn("Schedule");

            empTable.Border = TableBorder.SimpleHeavy;

            empTable.AddRow("  ", "                            ", "                       ", "00--02--04--06--08--10--12--14--16--18--20--22--TMRW");

            string[] createString = new string[34];

            int listMax = Math.Min(Program.employeeList.Count, page * 12 + 12);
            string finalString = "";

            for (int i = page * 12; i < listMax; i++)
            {
                string empMoniker = Program.employeeList[i].Name + " " + Program.employeeList[i].Surname;
                string empPos = Program.employeeList[i].Position;
                string empid = Program.employeeList[i].Id.ToString();

                if (empMoniker.Length > 28)
                {
                    empMoniker = Program.employeeList[i].Name.Substring(0, 1) + ". " + Program.employeeList[i].Surname;
                    if (empMoniker.Length > 28)
                    {
                        empMoniker = empMoniker.Substring(0, 25) + "...";
                    }
                }

                if (i == highlight)
                {
                    empid = "[orange1]" + empid + "[/]";
                    empMoniker = "[orange1]" + empMoniker + "[/]";
                }

                if (empPos.Length > 23)
                {
                    empPos = empPos.Substring(0, 20) + "...";
                }

                if (Program.employeeList[i].Shifts[day] >= 0 && Program.employeeList[i].Shifts[day] < Program.shiftList.Count)
                {
                    var shiftNum = Program.shiftList[Program.employeeList[i].Shifts[day]].TimeCode;

                    Block a;
                    for (int j = 0; j < 24; j++)
                    {
                        int blockIndex = shiftNum[j];
                        if (blockIndex >= 0 && blockIndex < Program.blockList.Count)
                        {
                            a = Program.blockList[blockIndex];
                            createString[j] = "[" + a.Color + "]" + a.Typeset + "[/]";
                        }
                    }

                    finalString = string.Join("", createString);
                    empTable.AddRow(empid, empMoniker, empPos, finalString);
                }
            }

            var pageDayView = new Markup("[khaki1]" + Global.week[day] + "[/]   [grey70]Page " + (page + 1) + "/" + (Program.employeeList.Count / 12 + 1) + "[/]");

            var empPanel = new Panel(new Rows(empTable, pageDayView));
            empPanel.Header = new PanelHeader(appTitle);
            empPanel.Border = BoxBorder.Heavy;
            empPanel.Padding = new Padding(0, 0, 0, 0);
            empPanel.Expand = true;
            AnsiConsole.Write(empPanel);
        }

        public static void DisplayEmployeePay(int page)
        {
            AnsiConsole.Clear();

            var empTable = new Table()
                .AddColumn("ID")
                .AddColumn("Name & Surname")
                .AddColumn("Position")
                .AddColumn("Hourly Wage")
                .AddColumn("Weekly Wage");

            empTable.Border = TableBorder.SimpleHeavy;

            empTable.AddRow("  ", "                            ", "                       ", "           ", "           ");

            double calcWage = 0.0;
            int listMax = Math.Min(Program.employeeList.Count, page * 12 + 12);

            for (int i = page * 12; i < listMax; i++)
            {
                calcWage = 0.0;

                string empMoniker = Program.employeeList[i].Name + " " + Program.employeeList[i].Surname;
                string empPos = Program.employeeList[i].Position;
                string empid = Program.employeeList[i].Id.ToString();
                double pay = Program.employeeList[i].Wage;

                if (empMoniker.Length > 28)
                {
                    empMoniker = Program.employeeList[i].Name.Substring(0, 1) + ". " + Program.employeeList[i].Surname;
                    if (empMoniker.Length > 28)
                    {
                        empMoniker = empMoniker.Substring(0, 25) + "...";
                    }
                }

                if (empPos.Length > 23)
                {
                    empPos = empPos.Substring(0, 20) + "...";
                }

                for (int j = 0; j < 7; j++)
                {
                    var shiftcheck = Program.shiftList[Program.employeeList[i].Shifts[j]].TimeCode;
                    for (int k = 0; k < 24; k++)
                    {
                        if (Program.blockList[shiftcheck[k]].IsOvertime)
                            calcWage = calcWage + pay * Global.OvertimeRate;
                        else if (shiftcheck[k] != 0)
                            calcWage = calcWage + pay;
                    }
                }

                calcWage = Math.Round(calcWage, 2);


                empTable.AddRow(empid, empMoniker, empPos, pay.ToString() + "/h", calcWage + "/w");
            }

            var pageDayView = new Markup("[grey70]Page " + (page + 1) + "/" + (Program.employeeList.Count / 12 + 1) + "[/]   Overtime Rate: [red]" + Global.OvertimeRate.ToString() + "[/]");

            var empPanel = new Panel(new Rows(empTable, pageDayView));
            empPanel.Header = new PanelHeader(appTitle);
            empPanel.Border = BoxBorder.Heavy;
            empPanel.Padding = new Padding(0, 0, 0, 0);
            empPanel.Expand = true;
            AnsiConsole.Write(empPanel);
        }
    
        public static void SuccessMessage(int code)
        {
            List<string> msgs = new List<string>
            {
                "[green3]Login details saved[/]", //0
                "[green3]Employee created successfully[/]", //1
                "[green3]Employee Deleted[/]", //2
                "[green3]Employee info updated successfully[/]" //3
            };

            AnsiConsole.MarkupLine(msgs[code]);
            Console.ReadKey(true);
        }

        public static void ErrorMessage(int code)
        {
            List<string> msgs = new List<string>
            {
                "[red]Login details are incorrect.[/]", //0
                "[red]Password is incorrect.[/]", //1
                "[red]You do not have permission to use this function![/]" //2
            };

            AnsiConsole.MarkupLine(msgs[code]);
            Console.ReadKey(true);
        }

        public static void StartUp()
        {
            AnsiConsole.Cursor.Hide();
            DataHandling.InitializeStandardResources();


            AnsiConsole.Write(
                new FigletText("Work                   ")
                    .Centered()
                    .Color(Color.Yellow));
            AnsiConsole.Write(
                new FigletText("                  Blocks")
                    .Centered()
                    .Color(Color.Magenta1));

            AnsiConsole.Write(
                new Text("\nPress Any Key")
                .Centered());

            Console.ReadKey(true);

            AnsiConsole.Clear();
        }

        public static void ShutDown()
        {
            AnsiConsole.Clear();
            AnsiConsole.MarkupLine("[yellow]We hope you enjoyed using[/] " + appTitle + " [yellow]:)[/]");
        }
    }
}
