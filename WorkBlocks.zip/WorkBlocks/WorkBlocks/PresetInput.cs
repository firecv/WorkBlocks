﻿using Spectre.Console;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkBlocks
{
    internal class PresetInput
    {
        static List<Color> choiceColors = new List<Color>
        {
            Color.Yellow,
            Color.CornflowerBlue,
            Color.Green3_1,
            Color.Purple4,
            Color.Orange1,
            Color.Red3_1,
            Color.Yellow1
        };

        static List<string> choiceTitles = new List<string>
        {
            "", "", "", "[yellow]What color block would you like to make?[/]", "", 
            "Are you sure you would like to delete this employee?", 
            "What day would you like to assign this shift to?"
        };

        static List<string[]> choiceList = new List<string[]>
        {
            new string[] {"ANALYZE SCHEDULE DETAILS",
                "Cycle Day",
                "Cycle Page\n",
                "View Wages",
                "Admin Log In",
                "Save File",
                "Read File\n",
                "Quit"},

            new string[]
            {
                "ANALYZE SCHEDULE DETAILS",
                "Cycle Day",
                "Cycle Page\n",
                "Create New Employee",
                "Manage Employees & Assign Shifts",
                "Create & Manage Shifts",
                "View Wages",
                "Edit Login Details",
                "Save File",
                "Read File\n",
                "Log Out"
            },

            new string[]
            {
                "Cycle Page",
                "Set Overtime Rate\n",
                "Back"
            },

            new string []
            {
                "WHITE",
                "GRAY",
                "MAGENTA",
                "PURPLE",
                "BLUE",
                "CYAN",
                "YELLOW",
                "GREEN",
                "RED - Overtime Hour (employee is paid double!)"
            },

            new string[]
            {
                "ANALYZE SCHEDULE DETAILS", //0
                "Cycle Day", //1
                "Cycle Page\n", //2
                "Assign Shift\n", //3
                "Edit Name", //4
                "Edit Surname", //5
                "Edit Position", //6
                "Edit Hourly Wage\n", //7
                "Delete Employee\n", //8
                "Back" //9
            },

            new string[]
            {
                "CONFIRM",
                "CANCEL"
            },

            new string[]
            {
                "MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"
            }
        };
        /*choiceList index guide:
         
        0. User Mode Menu Choices
        1. Admin Mode Menu Choices
        2. Employee Pay View Mode Choices
        3. Block Creation Color Choices
        4. Employee Editing Mode
        5. YES/NO Confirmation
        6. Day of the Week Selection
         */

        public static int StaticChoiceMenu(int menuIndex)
        {
            string choice;

            if (choiceTitles[menuIndex] == "")
            {
                choice = AnsiConsole.Prompt(
                            new SelectionPrompt<string>()
                                .HighlightStyle(new Style().Foreground(choiceColors[menuIndex]))
                                .AddChoices(choiceList[menuIndex])
                                .PageSize(6)
                                .MoreChoicesText("[grey]up/down for more options...[/]"));
            } else
            {
                choice = AnsiConsole.Prompt(
                            new SelectionPrompt<string>()
                                .HighlightStyle(new Style().Foreground(choiceColors[menuIndex]))
                                .AddChoices(choiceList[menuIndex])
                                .Title(choiceTitles[menuIndex])
                                .PageSize(10)
                                .MoreChoicesText("[grey]up/down for more options...[/]"));
            }

            int choiceIndex = Array.IndexOf(choiceList[menuIndex], choice);

            return choiceIndex;
        }

        public static List<string> ReadyShiftChoices(int mode)
        {
            List<string> allShifts = new List<string>();
            string[] createString = new string[26];

            allShifts.Clear();

            allShifts.Add("BACK");
            if (mode == 0)
                allShifts.Add("Create & Manage Shifts\n");
            else if (mode == 1)
            {
                AnsiConsole.Clear();
                allShifts.Add("Create New Shift");
            }

            foreach (Shift i in Program.shiftList)
            {
                createString[25] = i.Title;
                createString[24] = "  ";

                Block a;
                for (int j = 0; j < 24; j++)
                {
                    int blockIndex = i.TimeCode[j];
                    if (blockIndex >= 0 && blockIndex < Program.blockList.Count)
                    {
                        a = Program.blockList[blockIndex];
                        createString[j] = "[" + a.Color + "]" + a.Typeset + "[/]";
                    }
                }

                allShifts.Add(string.Join("", createString));
            }

            return allShifts;
        }

        public static List<string> ReadyBlockChoices()
        {
            List<string> allBlocks = new List<string>();
            string createString;

            allBlocks.Clear();

            allBlocks.Add("BACK");
            allBlocks.Add("Edit Shift Title");
            allBlocks.Add("Create New Block");

            foreach (Block i in Program.blockList)
            {
                createString = "[" + i.Color + "]" + i.Typeset + "[/] " + i.Title;

                allBlocks.Add(string.Join("", createString));
            }

            return allBlocks;
        }

        public static int DynamicChoiceMenu(int mode)
        {
            List<string> choices = new List<string>();
            if (mode == 0 || mode == 1)
                choices = ReadyShiftChoices(mode);
            else if (mode == 2)
                choices = ReadyBlockChoices();

            string choice = AnsiConsole.Prompt(
                        new SelectionPrompt<string>()
                            .HighlightStyle(new Style().Foreground(Color.Magenta1))
                            .AddChoices(choices)
                            .PageSize(14)
                            .MoreChoicesText("[grey]up/down for more options...[/]"));

            return choices.IndexOf(choice);
        }



        static List<string> reqTitles = new List<string>
        {
            "\nNew " + PresetOutput.fancyUsernamePrompt, //0
            "New " + PresetOutput.fancyPasswordPrompt, //1
            "Employee Name: ", //2
            "Employee Surname: ", //3
            "Employee Position: ", //4
            "Hourly Wage: ", //5 - Double
            "New Overtime Rate: ", //6 - Double
            "[yellow]New Block Title:[/] ", //7
            "Employee ID: ", //8
            "New Data: ", //9
            "New Shift Title: ", //10
            PresetOutput.fancyUsernamePrompt, //11
            PresetOutput.fancyPasswordPrompt //12
        };

        public static string Request(int index)
        {
            string getcha = AnsiConsole.Prompt(
                new TextPrompt<string>(reqTitles[index])
                    .PromptStyle("grey62")
                    .ValidationErrorMessage("[red]Input cannot be empty![/]")
                    .Validate(input => !string.IsNullOrWhiteSpace(input)));

            return getcha;
        }

        public static double RequestDouble(int index)
        {
            double conWage;
            while (true)
            {
                string newWage = AnsiConsole.Prompt(
                    new TextPrompt<string>(reqTitles[index])
                        .PromptStyle("grey62")
                        .ValidationErrorMessage("[red]Cannot be empty![/]")
                        .Validate(input => !string.IsNullOrWhiteSpace(input)));

                if (Double.TryParse(newWage, out conWage))
                    break;
                else
                    AnsiConsole.MarkupLine("[red]Input must be a number[/]");
            }

            return conWage;
        }

        public static int RequestInt(int index)
        {
            int conWage;
            while (true)
            {
                string newWage = AnsiConsole.Prompt(
                    new TextPrompt<string>(reqTitles[index])
                        .PromptStyle("grey62")
                        .ValidationErrorMessage("[red]Cannot be empty![/]")
                        .Validate(input => !string.IsNullOrWhiteSpace(input)));

                if (Int32.TryParse(newWage, out conWage))
                    break;
                else
                    AnsiConsole.MarkupLine("[red]Input must be a number[/]");
            }

            return conWage;
        }

        public static string RequestTypeset()
        {
            AnsiConsole.Clear();

            string getcha = AnsiConsole.Prompt(
                new TextPrompt<string>("\n[yellow]How would you like your block to be marked?\nThe mark must be 2 characters.[/]\t")
                    .PromptStyle("grey62")
                    .ValidationErrorMessage("[red]Mark length must be equal to 2![/]")
                    .Validate(input => input.Length == 2));

            return getcha;
        }

        public static bool RequestConfirmation()
        {
            AnsiConsole.MarkupLine("[red]Though it will not cause any issues, it is not suggested to edit default shifts.\nIf you wish to edit this shift anyway, press[/] [yellow]SPACE[/]\n[red]Otherwise, press[/] [blue]any other key[/] [yellow]to return to the previous screen.[/]");
            var keycheck = Console.ReadKey(true);
            if (keycheck.Key == ConsoleKey.Spacebar)
            {
                return true;
            }
            else
                return false;
        }


        public static void AnalysisMode(int page, int day)
        {
            if (Program.employeeList.Count == 0)
            {
                AnsiConsole.MarkupLine("[red]No employees to analyze.\nPlease load a file before attempting analysis.[/]");
                Console.ReadKey(true);
                return;
            }
            AnsiConsole.Cursor.Show();
            int cursorX = 66;
            int cursorY = 5;
            int scrollMax = Math.Min(Program.employeeList.Count, page * 12 + 12) - (page * 12);

            Console.SetCursorPosition(cursorX, cursorY);

            PresetOutput.DisplayShiftBlocks(page, day);
            PresetOutput.GenerateDetailText(page, day, cursorX, cursorY);

            while (true)
            {
                var keypress = Console.ReadKey(true);

                switch (keypress.Key)
                {
                    case ConsoleKey.UpArrow:
                        if (cursorY > 5)
                            cursorY = cursorY - 1;
                        break;
                    case ConsoleKey.DownArrow:
                        if (cursorY < 4 + scrollMax)
                            cursorY = cursorY + 1;
                        break;
                    case ConsoleKey.LeftArrow:
                        if (cursorX >= 68)
                            cursorX = cursorX - 2;
                        break;
                    case ConsoleKey.RightArrow:
                        if (cursorX <= 110)
                            cursorX = cursorX + 2;
                        break;
                    case ConsoleKey.Escape:
                        AnsiConsole.Cursor.Hide();
                        return;
                }

                /*if (keypress.Key == ConsoleKey.Escape)
                    break;*/

                if (keypress.Key != null)
                {
                    AnsiConsole.Clear();
                    PresetOutput.DisplayShiftBlocks(page, day);
                    PresetOutput.GenerateDetailText(page, day, cursorX, cursorY);
                }

                Console.SetCursorPosition(cursorX, cursorY);
            }
        }

        public static void ShiftBlockInsertion(int shiftEdit, int choice)
        {
            int cursorX = 35, cursorY = 7;

            while (true)
            {
                AnsiConsole.Cursor.Show();
                AnsiConsole.Clear();
                PresetOutput.DisplaySingleShift(shiftEdit);
                AnsiConsole.MarkupLine("Move the cursor with [yellow]left/right[/]. Insert a block with [yellow]SPACE or ENTER[/], or press [yellow]esc[/] to quit.");
                Console.SetCursorPosition(cursorX, cursorY);

                var keypress = Console.ReadKey(true);

                switch (keypress.Key)
                {
                    case ConsoleKey.LeftArrow:
                        if (cursorX > 35)
                            cursorX = cursorX - 2;
                        break;
                    case ConsoleKey.RightArrow:
                        if (cursorX < 81)
                            cursorX = cursorX + 2;
                        break;
                    case ConsoleKey.Spacebar:
                    case ConsoleKey.Enter:
                        Program.shiftList[shiftEdit].TimeCode[(cursorX - 35) / 2] = (choice - 3);
                        break;
                    case ConsoleKey.Escape:
                        AnsiConsole.Cursor.Hide();
                        break;
                }

                if (keypress.Key == ConsoleKey.Escape)
                {
                    AnsiConsole.Cursor.Hide();
                    break;
                }
            }
        }

        public static bool Login()
        {
            var userPass = DataHandling.GetLoginDetails().Split();

            string login = Request(11);

            string password = Request(12);

            if (login == userPass[0] && password == userPass[1])
            {
                return true;
            }

            return false;
        }

        public static bool LoginPassOnly()
        {
            string line = File.ReadAllText("wbLogin.txt");
            var userPass = line.Split();

            string oldPassword = AnsiConsole.Prompt(
                new TextPrompt<string>("Old " + PresetOutput.fancyPasswordPrompt)
                    .PromptStyle("grey62")
                    .Secret()
                    .ValidationErrorMessage("[red]Password cannot be empty![/]")
                    .Validate(input => !string.IsNullOrWhiteSpace(input)));

            if (oldPassword == userPass[1])
                return true;
            else
                return false;
        }

        public static void LoginDetailChangeAttempt() {
            if (LoginPassOnly())
            {
                string newLogin = Request(0);

                string newPassword = Request(1);

                DataHandling.ChangeLoginDetails(newLogin, newPassword);

                PresetOutput.SuccessMessage(0);
            }
            else
            {
                PresetOutput.ErrorMessage(1);
            }
        }
        public static void WaitOnPress()
        {

        }
    }
}
